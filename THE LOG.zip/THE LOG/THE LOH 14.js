/* ==========================================================================
   THE LOG — APP
   Ties everything together: a tiny hash router decides which render*
   function to call; one delegated click listener reads data-action off
   whatever was clicked and dispatches to a handler; every handler mutates
   state then calls render() again. This "one direction of data flow" is
   the same core idea behind frameworks like React — we're just doing the
   wiring by hand instead of a library doing it for us.
   ========================================================================== */

import * as S from "./state.js";
import * as R from "./render.js";
import * as M from "./modals.js";

const viewRoot = document.getElementById("view-root");
const body = document.body;

let insightsPeriod = "week";
let plannerWeekOffset = 0;

/* ---------------------------------------------------------------------- */
/* ROUTER                                                                  */
/* ---------------------------------------------------------------------- */

const SECTIONS = ["menu", "study", "gym", "learning", "planner", "insights", "review"];

function parseHash() {
  const raw = location.hash.replace(/^#\/?/, "");
  const [section, id] = raw.split("/");
  if (!SECTIONS.includes(section)) return { section: "menu", id: null };
  return { section, id: id || null };
}

function route() {
  const { section, id } = parseHash();
  body.dataset.section = section === "review" ? "planner" : section; // review shares planner's color identity family visually but keep as planner theme
  updateNav(section);

  let html = "";
  if (section === "menu") html = R.renderMenu();
  else if (section === "study") {
    if (id) {
      const subject = S.getSubject(id);
      html = subject ? R.renderSubjectDetail(subject) : R.renderStudyList();
    } else html = R.renderStudyList();
  } else if (section === "gym") html = R.renderGym();
  else if (section === "learning") html = R.renderLearning();
  else if (section === "planner") html = R.renderPlanner(plannerWeekOffset);
  else if (section === "insights") html = R.renderInsights(insightsPeriod);
  else if (section === "review") html = R.renderWeeklyReview();

  viewRoot.innerHTML = html;
  window.scrollTo({ top: 0, behavior: "instant" in window ? "instant" : "auto" });
}

function updateNav(section) {
  document.querySelectorAll("[data-nav-link]").forEach((el) => {
    el.classList.toggle("active", el.dataset.navLink === section || (section === "review" && el.dataset.navLink === "planner"));
  });
}

window.addEventListener("hashchange", route);

/* ---------------------------------------------------------------------- */
/* TOAST                                                                   */
/* ---------------------------------------------------------------------- */

function toast(msg) {
  const host = document.getElementById("toast-host");
  const el = document.createElement("div");
  el.className = "toast";
  el.textContent = msg;
  host.appendChild(el);
  setTimeout(() => el.remove(), 2200);
}

/* ---------------------------------------------------------------------- */
/* MODAL OPENERS                                                           */
/* ---------------------------------------------------------------------- */

function handleAddSubject() {
  M.openModal(M.tplAddSubject(), (root) => {
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const name = new FormData(e.target).get("name").trim();
      if (!name) return;
      S.addSubject(name);
      M.closeModal();
      route();
      toast("Subject added");
    });
  });
}

function handleAddLesson(subjectId) {
  M.openModal(M.tplAddLesson(), (root) => {
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const title = new FormData(e.target).get("title").trim();
      if (!title) return;
      S.addLesson(subjectId, title);
      M.closeModal();
      route();
      toast("Lesson added");
    });
  });
}

function handleAddExam(subjectId) {
  M.openModal(M.tplAddExam(), (root) => {
    M.wireExamTypeMax(root);
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      S.addExam(subjectId, {
        name: fd.get("name").trim(),
        chapter: fd.get("chapter").trim(),
        type: fd.get("type"),
        max: fd.get("max"),
        score: fd.get("score"),
        date: fd.get("date")
      });
      M.closeModal();
      route();
      toast("Exam added");
    });
  });
}

function handleExplanation(subjectId, lessonId) {
  const subject = S.getSubject(subjectId);
  const lesson = subject?.lessons.find((l) => l.id === lessonId);
  if (!lesson) return;
  M.openModal(M.tplExplanation(lesson), (root) => {
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      S.updateLesson(subjectId, lessonId, {
        whatIUnderstood: fd.get("whatIUnderstood"),
        whatIDidnt: fd.get("whatIDidnt"),
        toReview: fd.get("toReview"),
        notes: fd.get("notes")
      });
      M.closeModal();
      toast("Notes saved");
    });
  });
}

function handleAddWorkout() {
  let rowCount = 0;
  M.openModal(M.tplAddWorkout(S.state.gym.categories), (root) => {
    const rowsHost = root.querySelector("#exercise-rows");
    function addRow() {
      const div = document.createElement("div");
      div.innerHTML = M.exerciseRowHtml(rowCount++);
      rowsHost.appendChild(div.firstElementChild);
    }
    addRow();
    root.querySelector("#add-exercise-row").addEventListener("click", addRow);

    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      const exercises = [];
      for (let i = 0; i < rowCount; i++) {
        const name = fd.get(`ex-name-${i}`);
        if (!name || !name.trim()) continue;
        exercises.push({
          name: name.trim(),
          sets: Number(fd.get(`ex-sets-${i}`)) || 0,
          reps: Number(fd.get(`ex-reps-${i}`)) || 0,
          weight: Number(fd.get(`ex-weight-${i}`)) || 0
        });
      }
      S.addWorkout(fd.get("category"), fd.get("date"), exercises);
      M.closeModal();
      route();
      toast("Workout logged");
    });
  });
}

function handleAddPath() {
  M.openModal(M.tplAddPath(), (root) => {
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const name = new FormData(e.target).get("name").trim();
      if (!name) return;
      S.addLearningPath(name);
      M.closeModal();
      route();
      toast("Path added");
    });
  });
}

function handleAddPathItem(pathId) {
  M.openModal(M.tplAddPathItem(), (root) => {
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const title = new FormData(e.target).get("title").trim();
      if (!title) return;
      S.addLearningItem(pathId, title);
      M.closeModal();
      route();
    });
  });
}

function handleAddProject() {
  M.openModal(M.tplAddProject(), (root) => {
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      S.addProject({
        name: fd.get("name").trim(),
        status: fd.get("status"),
        whatBuilt: fd.get("whatBuilt"),
        whatLearned: fd.get("whatLearned"),
        problems: fd.get("problems"),
        nextStep: fd.get("nextStep")
      });
      M.closeModal();
      route();
      toast("Project added");
    });
  });
}

function handleAddSession() {
  M.openModal(M.tplAddSession(), (root) => {
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      S.addLearningSession({
        topic: fd.get("topic").trim(),
        hours: fd.get("hours"),
        difficulty: fd.get("difficulty"),
        notes: fd.get("notes"),
        questions: fd.get("questions"),
        unclear: fd.get("unclear")
      });
      M.closeModal();
      route();
      toast("Session logged");
    });
  });
}

function handleAddTask(date, priority) {
  const d = date || new Date().toISOString().slice(0, 10);
  M.openModal(M.tplAddTask(d, priority === "1"), (root) => {
    root.querySelector("#modal-form").addEventListener("submit", (e) => {
      e.preventDefault();
      const fd = new FormData(e.target);
      S.addTask({
        title: fd.get("title").trim(),
        type: fd.get("type"),
        date: fd.get("date"),
        isPriority: fd.get("isPriority") === "on"
      });
      M.closeModal();
      route();
      toast("Task added");
    });
  });
}

/* ---------------------------------------------------------------------- */
/* GLOBAL EVENT DELEGATION                                                 */
/* ---------------------------------------------------------------------- */

document.addEventListener("click", (e) => {
  const closeBtn = e.target.closest("[data-close-modal]");
  if (closeBtn) { M.closeModal(); return; }

  const el = e.target.closest("[data-action]");
  if (!el) return;
  const action = el.dataset.action;

  switch (action) {
    case "open-add-subject": handleAddSubject(); break;
    case "delete-subject":
      if (confirm("Delete this subject and all its exams and lessons?")) {
        S.deleteSubject(el.dataset.subject);
        location.hash = "#/study";
      }
      break;
    case "open-add-lesson": handleAddLesson(el.dataset.subject); break;
    case "open-add-exam": handleAddExam(el.dataset.subject); break;
    case "delete-exam": S.deleteExam(el.dataset.subject, el.dataset.exam); route(); break;
    case "delete-lesson": S.deleteLesson(el.dataset.subject, el.dataset.lesson); route(); break;
    case "set-understanding":
      S.updateLesson(el.dataset.subject, el.dataset.lesson, { understanding: el.dataset.level });
      route();
      break;
    case "open-explanation": handleExplanation(el.dataset.subject, el.dataset.lesson); break;

    case "open-add-workout": handleAddWorkout(); break;
    case "delete-workout": S.deleteWorkout(el.dataset.workout); route(); break;

    case "open-add-path": handleAddPath(); break;
    case "open-add-path-item": handleAddPathItem(el.dataset.path); break;
    case "toggle-learning-item": S.toggleLearningItem(el.dataset.path, el.dataset.item); route(); break;
    case "open-add-project": handleAddProject(); break;
    case "open-add-session": handleAddSession(); break;
    case "delete-learning-session": S.deleteLearningSession(el.dataset.session); route(); break;

    case "open-add-task": handleAddTask(el.dataset.date, el.dataset.priority); break;
    case "toggle-task": S.toggleTask(el.dataset.task); route(); break;
    case "delete-task": S.deleteTask(el.dataset.task); route(); break;
    case "week-prev": plannerWeekOffset--; route(); break;
    case "week-next": plannerWeekOffset++; route(); break;

    case "set-insights-period": insightsPeriod = el.dataset.period; route(); break;
  }
});

document.addEventListener("change", (e) => {
  const el = e.target.closest("[data-action='update-project-status']");
  if (el) {
    S.updateProject(el.dataset.project, { status: el.value });
    toast("Project status updated");
  }
});

/* ---------------------------------------------------------------------- */
/* INIT                                                                     */
/* ---------------------------------------------------------------------- */

if (!location.hash) location.hash = "#/menu";
route();
